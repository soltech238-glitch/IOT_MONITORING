/* =========================
   SYSTEM VARIABLES
========================= */

let system = true;
let charging = false;
let fan = false;
let load = true;
let alarm = true;
let monitoring = true;

let mode = "AUTO";

let energy = 0;

let powerHistory = [];
let efficiencyHistory = [];


/* =========================
   PAGE NAVIGATION
========================= */

function showPage(page) {

    const pages = [
        "dashboard",
        "control",
        "reports"
    ];

    pages.forEach(function (pageName) {

        const element =
            document.getElementById(pageName);

        if (element) {
            element.classList.add("hidden");
        }
    });


    const selectedPage =
        document.getElementById(page);

    if (selectedPage) {
        selectedPage.classList.remove("hidden");
    }


    /* Redraw graph when dashboard becomes visible */

    if (page === "dashboard") {

        setTimeout(function () {
            drawChart();
        }, 50);
    }
}


/* =========================
   CONTROL SYSTEM
========================= */

function toggleControl(type) {

    switch (type) {

        case "system":

            system = !system;

            updateButton(
                "systemBtn",
                system,
                "🟢 SYSTEM ON",
                "🔴 SYSTEM OFF"
            );

            addLog(
                system
                    ? "Main system turned ON"
                    : "Main system turned OFF"
            );

            break;


        case "charging":

            charging = !charging;

            updateButton(
                "chargingBtn",
                charging,
                "🟢 CHARGING ON",
                "🔴 CHARGING OFF"
            );

            addLog(
                charging
                    ? "Battery charging STARTED"
                    : "Battery charging STOPPED"
            );

            break;


        case "fan":

            fan = !fan;

            updateButton(
                "fanBtn",
                fan,
                "🟢 FAN ON",
                "🔴 FAN OFF"
            );

            addLog(
                fan
                    ? "Cooling fan turned ON"
                    : "Cooling fan turned OFF"
            );

            break;


        case "load":

            load = !load;

            updateButton(
                "loadBtn",
                load,
                "🟢 LOAD ON",
                "🔴 LOAD OFF"
            );

            addLog(
                load
                    ? "Solar load turned ON"
                    : "Solar load turned OFF"
            );

            break;


        case "alarm":

            alarm = !alarm;

            updateButton(
                "alarmBtn",
                alarm,
                "🟢 ALARM ENABLED",
                "🔴 ALARM DISABLED"
            );

            addLog(
                alarm
                    ? "Alarm enabled"
                    : "Alarm disabled"
            );

            break;


        case "monitor":

            monitoring = !monitoring;

            updateButton(
                "monitorBtn",
                monitoring,
                "🟢 MONITORING ON",
                "🔴 MONITORING OFF"
            );

            addLog(
                monitoring
                    ? "Monitoring started"
                    : "Monitoring stopped"
            );

            updateReports();

            break;
    }
}


/* =========================
   UPDATE CONTROL BUTTON
========================= */

function updateButton(
    id,
    state,
    onText,
    offText
) {

    const button =
        document.getElementById(id);

    if (!button) {
        return;
    }


    button.innerText =
        state ? onText : offText;


    button.className =
        state
            ? "control-btn on"
            : "control-btn off";
}


/* =========================
   AUTO / MANUAL MODE
========================= */

function setMode(newMode) {

    mode = newMode;


    document.getElementById("mode").innerText =
        mode;

    document.getElementById("reportMode").innerText =
        mode;


    const autoButton =
        document.getElementById("autoBtn");

    const manualButton =
        document.getElementById("manualBtn");


    autoButton.classList.remove("mode-active");
    manualButton.classList.remove("mode-active");


    if (mode === "AUTO") {

        autoButton.classList.add("mode-active");

        addLog(
            "Operating mode changed to AUTO"
        );

    } else {

        manualButton.classList.add("mode-active");

        addLog(
            "Operating mode changed to MANUAL"
        );
    }
}


/* =========================
   ACTIVITY LOG
========================= */

function addLog(message) {

    const log =
        document.getElementById("log");

    if (!log) {
        return;
    }


    const time =
        new Date().toLocaleTimeString();


    const entry =
        document.createElement("div");


    entry.innerText =
        "[" + time + "] " + message;


    log.prepend(entry);
}


/* =========================
   SOLAR DATA SIMULATION
========================= */

function updateSolarData() {

    /*
       Monitoring OFF hone par
       data update nahi hoga.
    */

    if (!monitoring) {
        return;
    }


    /* Voltage */

    let voltage =
        17 + Math.random() * 2;


    /* Current */

    let current =
        3 + Math.random() * 2;


    /* Sunlight */

    let sunlight =
        50 + Math.random() * 50;


    /* Temperature */

    let temperature =
        28 + Math.random() * 20;


    /* Random Cloud */

    if (Math.random() < 0.15) {

        sunlight =
            15 + Math.random() * 25;

        voltage =
            13 + Math.random() * 3;

        current =
            0.5 + Math.random();
    }


    /* Power */

    let power =
        voltage * current;


    /* Solar Load OFF */

    if (!load) {

        power =
            power * 0.1;
    }


    /* System OFF */

    if (!system) {

        power = 0;
    }


    /* Energy */

    energy +=
        power / 3600;


    /* Efficiency */

    let efficiency =
        Math.min(
            power,
            100
        );


    /* Condition */

    let condition;


    if (sunlight >= 70) {

        condition = "☀️ Sunny";

    } else if (sunlight >= 40) {

        condition = "⛅ Partly Cloudy";

    } else {

        condition = "☁️ Cloudy";
    }


    /* =========================
       UPDATE DASHBOARD
    ========================= */

    document.getElementById("voltage").innerText =
        voltage.toFixed(2) + " V";


    document.getElementById("current").innerText =
        current.toFixed(2) + " A";


    document.getElementById("power").innerText =
        power.toFixed(2) + " W";


    document.getElementById("energy").innerText =
        energy.toFixed(2) + " Wh";


    document.getElementById("temperature").innerText =
        temperature.toFixed(1) + " °C";


    document.getElementById("sunlight").innerText =
        sunlight.toFixed(0) + " %";


    document.getElementById("efficiency").innerText =
        efficiency.toFixed(1) + " %";


    document.getElementById("condition").innerText =
        condition;


    document.getElementById("weather").innerText =
        condition;


    /* =========================
       SYSTEM STATUS
    ========================= */

    const status =
        document.getElementById("systemStatus");


    if (!system) {

        status.innerText =
            "🔴 SYSTEM OFF";

        status.className =
            "red";

    } else if (power < 20 && alarm) {

        status.innerText =
            "⚠️ LOW SOLAR POWER";

        status.className =
            "orange";

    } else {

        status.innerText =
            "● System Working Normally";

        status.className =
            "green";
    }


    /* =========================
       GRAPH DATA
    ========================= */

    powerHistory.push(power);

    efficiencyHistory.push(efficiency);


    /* Keep last 30 values */

    if (powerHistory.length > 30) {

        powerHistory.shift();
        efficiencyHistory.shift();
    }


    /* Update reports */

    updateReports();


    /* Update graph */

    drawChart();
}


/* =========================
   REPORTS
========================= */

function updateReports() {

    if (powerHistory.length === 0) {
        return;
    }


    const maxPower =
        Math.max(...powerHistory);


    const averagePower =
        powerHistory.reduce(
            function (total, value) {
                return total + value;
            },
            0
        ) / powerHistory.length;


    const averageEfficiency =
        efficiencyHistory.reduce(
            function (total, value) {
                return total + value;
            },
            0
        ) / efficiencyHistory.length;


    document.getElementById("maxPower").innerText =
        maxPower.toFixed(2) + " W";


    document.getElementById("averagePower").innerText =
        averagePower.toFixed(2) + " W";


    document.getElementById("totalEnergy").innerText =
        energy.toFixed(2) + " Wh";


    document.getElementById("averageEfficiency").innerText =
        averageEfficiency.toFixed(1) + " %";


    document.getElementById("reportMonitoring").innerText =
        monitoring ? "ON" : "OFF";


    document.getElementById("reportMode").innerText =
        mode;
}


/* =========================
   DRAW POWER GRAPH
========================= */

function drawChart() {

    const canvas =
        document.getElementById("chart");


    if (!canvas) {
        return;
    }


    const context =
        canvas.getContext("2d");


    const width =
        canvas.clientWidth || 600;


    const height = 300;


    /* High-quality canvas */

    const devicePixelRatio =
        window.devicePixelRatio || 1;


    canvas.width =
        width * devicePixelRatio;


    canvas.height =
        height * devicePixelRatio;


    context.setTransform(
        devicePixelRatio,
        0,
        0,
        devicePixelRatio,
        0,
        0
    );


    context.clearRect(
        0,
        0,
        width,
        height
    );


    /* Background */

    context.fillStyle =
        "#fafafa";

    context.fillRect(
        0,
        0,
        width,
        height
    );


    if (powerHistory.length < 2) {
        return;
    }


    const maxPower =
        Math.max(
            ...powerHistory,
            100
        );


    /* =========================
       GRID
    ========================= */

    context.strokeStyle =
        "#e5e7eb";

    context.lineWidth = 1;


    for (let i = 0; i <= 5; i++) {

        const y =
            20 + i * 50;


        context.beginPath();

        context.moveTo(
            0,
            y
        );

        context.lineTo(
            width,
            y
        );

        context.stroke();
    }


    /* =========================
       POWER LINE
    ========================= */

    context.beginPath();

    context.strokeStyle =
        "#ff9800";

    context.lineWidth = 3;


    powerHistory.forEach(
        function (power, index) {

            const x =
                index /
                (powerHistory.length - 1) *
                width;


            const y =
                height -
                (power / maxPower) * 250 -
                20;


            if (index === 0) {

                context.moveTo(
                    x,
                    y
                );

            } else {

                context.lineTo(
                    x,
                    y
                );
            }
        }
    );


    context.stroke();


    /* =========================
       GRAPH POINTS
    ========================= */

    context.fillStyle =
        "#ff9800";


    powerHistory.forEach(
        function (power, index) {

            const x =
                index /
                (powerHistory.length - 1) *
                width;


            const y =
                height -
                (power / maxPower) * 250 -
                20;


            context.beginPath();

            context.arc(
                x,
                y,
                3,
                0,
                Math.PI * 2
            );

            context.fill();
        }
    );
}


/* =========================
   WINDOW RESIZE
========================= */

window.addEventListener(
    "resize",
    function () {

        drawChart();
    }
);


/* =========================
   START APPLICATION
========================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        addLog(
            "Solar monitoring system started"
        );

        addLog(
            "System initialized"
        );

        addLog(
            "AUTO mode enabled"
        );


        /* Initial data */

        updateSolarData();


        /* Update every second */

        setInterval(
            updateSolarData,
            1000
        );
    }
);